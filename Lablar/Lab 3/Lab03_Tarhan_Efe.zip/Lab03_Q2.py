#a)Defining the hailstone function

def hailstone(n):
    """
    Takes an integer n. Shows and prints the hailstone sequence of that integer. 
    Hailstone Sequence: If given number n is odd, muliply n with 3 and add 1. If n is even, divide n by 2. Do that until you reach 1
    
    Parameters:
    n (int) : Integer that will be calculated for hailstone sequence
    
    Returns:
    None
    """
  
    
    print(n, end = "\t")
    while n != 1 :
        if n % 2 == 0 :
            n /= 2
            print(int(n), end = "\t")
        else:
            n = 3 * n + 1
            print(int(n), end = "\t")
    print("\n")
        
        
        
            
            
        

#b) Displaying the hailstone sequence of all integers between 5-10

for i in range(5,11):
    hailstone(i)