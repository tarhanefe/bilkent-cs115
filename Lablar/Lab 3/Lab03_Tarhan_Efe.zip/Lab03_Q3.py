# a)Defining the sumDigits() function:
def sumDigits(x):
    """
    Takes a positive integer value and returns the
    total sum of the digits in the integers from 1 to that number inclusive
    
    Parameters:
    x (int) : The number that'll be get as input

    Returns:
    y(int): Returns the sum of digits from n to 1
    """
    y = 0
    
    for p in range(1, x+1):
        q = 0
        while p:
            q += p % 10
            p //= 10
        y += q
        
    return y
   
#b) Writing the program

x = int(input("Enter a positive integer: "))

if 0 < x :
    print ("The sum of the digits in the number from 1 to {} is {}".format(x, sumDigits(x)))
else:
    print("Value must be Positive")
        
    