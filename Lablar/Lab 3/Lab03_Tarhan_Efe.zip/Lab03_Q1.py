#PART A:
#Defining the first function : is_vowel()

def is_vowel(pm1):

    """
    
    Takes a string and returns True if this string is a single vowel
    character (case-insensitive), False otherwise.
    
    Parameters: pm1(str) : The string that'll be examined 
    
    Returns:
    opt1(Bool): If pm1 is a vowel it returns as True, else False
    """
    vowels = "aeiouAEUIO"
    if pm1 in vowels and len(pm1) == 1:
        opt1 = True
    else:
        opt1 = False
    return opt1
#Defining the second function : count_vowels()

def count_vowels(pm2):
    
    
    """
    Takes a string abd counts and returns the number of vowels in this string using is_vowel() function(case-insensitive)
    
    Parameters: pm2 (str): The string that'll be examined 
    
    Returns:
    opt2(int): Returns the number of vowels inside pm2
    """
    opt2 = 0
    n = 0
    while n < len(pm2):
        if is_vowel(pm2[n]):
            opt2 += 1
            n += 1
        else:
            n += 1
    return opt2

#Defining the third function : all_vowels()

def all_vowels(pm3):
    """
    Takes a string and checks if all vowels exist in this string or not.
    The function will return True if all exist, otherwise False will be returned.(case-insensitive)
    
    Parameters: pm3 (str): The string that'll be examined
    
    Returns: 
    opt3(bool): If pm3 contains all vowels it returns True, else False

    """
    if ("a" in pm3) and ("i" in pm3) and ("e" in pm3) and ("o" in pm3) and ("u" in pm3):
        opt3 = True
    else:
        opt3 = False
    return opt3

#Defining the fourth function: display_which_vowels()

def display_which_vowels(pm4):
    """
    Takes a string and displays which vowels exist in the
    string.(Case-insensitive)
    
    Parameters: pm4 (str) : The string that'll we be examined
    
    Returns:
    None
    """
    
    if "a" in pm4:
        print("\"a\" exists in \"{}\"".format(pm4))
    if "e" in pm4:
        print("\"e\" exists in \"{}\"".format(pm4))
    if "i" in pm4:
        print("\"i\" exists in \"{}\"".format(pm4))
    if "o" in pm4:
        print("\"o\" exists in \"{}\"".format(pm4))
    if "u" in pm4:
        print("\"u\" exists in \"{}\"".format(pm4))

#Defining the fifth function: capitalize_vowels()

def capitalize_vowels(pm5):
    """
    Takes a string and creates a new string by capitalizing the
    vowels in the given string
    
    Parameters: 
    pm5 (str): String that'll be exmined

    Returns:
    None
    """
    n = 0
    opt4 = ""
    while n < len(pm5):
        if is_vowel(pm5[n]):
            opt4 += pm5[n].upper()
        else:
            opt4 += pm5[n]
        n += 1
    print("New String: {}".format(opt4))
            
#PART B:
#Getting a string from the user

x = input("Enter a string: ")

print("There are {} number of vowels".format(count_vowels(x)))

if all_vowels(x):
    print("All Vowels exist in the given string" )

display_which_vowels(x)
capitalize_vowels(x)


    