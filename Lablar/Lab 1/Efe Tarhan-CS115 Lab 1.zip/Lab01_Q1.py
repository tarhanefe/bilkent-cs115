#Get inputs from user
a = float(input("Enter a: "))
b = float(input("Enter b: "))
c = float(input("Enter c: "))

#Calculate the result

k = ((a * b) + (b * c) + (a * c))/(a + b + c)

 
#Show the result with print function
print("The result of the calculation is {:.2f}".format(k))


