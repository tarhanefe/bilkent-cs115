#Get input from the user
name = input("Enter name: ")
surname = input("Enter surname: ")
title = input("Enter title: ")

#Print the function
print("Person is: {}. {}, {}.".format(title[0:4], surname, name[0]))