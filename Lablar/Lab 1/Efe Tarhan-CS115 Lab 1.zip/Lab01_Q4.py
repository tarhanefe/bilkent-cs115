#Print the first statement
print("This program converts feet and inches to centimeters")

#Getting values from the user
feet = int(input("Enter number of feet: "))
inches = int(input("Enter number of inches: "))

#Calculating the feet and inch to centimeter
cm = (feet * 12 + inches) * 2.54

#Printing the values
print("{} ft {} in = {} cm".format(feet, inches, cm))
