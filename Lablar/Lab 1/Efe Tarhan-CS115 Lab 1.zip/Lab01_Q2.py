#Get the inputs from the user
Team_name = input("Enter name of the team: ")

Games_won = int(input("Enter number of games won: "))

Games_lost = int(input("Enter number of games lost: "))

#Calculate the result of percentage
k = 100*((Games_won)/(Games_lost + Games_won))


#Print the function
print("{} won {:.1f}% of their games".format(Team_name , k))


