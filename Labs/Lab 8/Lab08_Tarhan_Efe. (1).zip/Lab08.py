#İmports the Outpatient module as class
from Outpatient import*
# Defining a schedulePatients function to create Outpatient objects and stroe them in a list
def schedulePatients(file):
    """
    İnputs a file, puts the elements in the file to the list as a Outpatient object. Returns the list

    Parameters
    ----------
    file : string
        the file that  containts the information .

    Returns
    -------
    m : list
        list with elements of Outpatient objects.

    """
    m = []
    q = open(file,"r")
    for i in q:
        b = i.strip().split(";")
          
        if len(b)== 6:
            m.append(Outpatient(b[0],b[5],b[1],b[2],b[4],b[3]))
        else:
            m.append(Outpatient(b[0],b[5],b[1],b[2],b[4],b[3],b[6]))
    q.close()
    return m
       

         

m = schedulePatients("patients.txt")

#Reordering the objects
m.sort()

print(m)    

