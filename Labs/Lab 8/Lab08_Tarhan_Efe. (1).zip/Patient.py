#Creating a patient class that'll contain imformation about patients
class Patient:
    
    __hospitalFee = 200
#Defining the __init__ function to create objects in patient class  
    def __init__(self, pName, isInsured, coveragePercent = 0):
        """
        Defining __init__ function to create Patient objects

        Parameters
        ----------
        pName : string
            Name of the patient object.
        isInsured : string
            Information of insurance of patient object.
        coveragePercent : string, 
            Percentage of the deduction of hospital fee . The default is 0.

        Returns
        -------
        None.

        """
        self.__pName = pName
        self.__isInsured = isInsured
        self.set_coveragePercent(coveragePercent)
    
#Defining a get_pName function to get the name of the object  
    def get_pName(self):
        """
        Returns the name of the patient object as a string

        Returns
        -------
        str(self.__name)
            pName of the object.

        """
        return self.__pName
    
#Defining a get_isInsured function to get the existance of insurance of the object      
    def get_isInsured(self):
        """
        Returns the value of insurance 

        Returns
        -------
        str(self.__isInsured)
            a boolean expression in a string format.

        """
        return self.isInsured
   
#Defining a get_coveragePercent function to get the value of coverage percent of the object      
    def get_coveragePercent(self):
        """
       Rertuns the value of coverage rate

        Returns
        -------
        str(self.__coveragePercent)
            value of the deduction of the hospital fee.

        """
        return self.__coveragePercent
    
#Defining a get_hospitalFee function to get the value of hospital fee of the object      
    def get_hospitalFee(self):
        """
        Returns the value of hospital fee

        Returns
        -------
        int
            hospital fee.

        """
        return self.__hospitalFee
        
#Defining a set_pName function to set a new name to the object 
    def set_pName(self, value):
        """
        Changes the pName of a Patient object

        Parameters
        ----------
        value : str
            new pName of the object.

        Returns
        -------
        self.__value(str)
            new name of patient object.

        """
        self.__pName = value
    
#Defining a set_isInsured function to set a new insurence existance to the object     
    def set_isInsured(self, value):
       """
        Assigns a new value to the __isInsured variable of an objects

        Parameters
        ----------
        value : str
            str version of the assigned boolean expression.

        Returns
        -------
        self.__isInsured : str
            new value of the __isInsurance.

        """ 
       self.__isInsured = value
       
    
#Defining a set_coveragePercent function to set a new value of coverage percentage to the object     
    def set_coveragePercent(self, value):
        """
        Assigns a new value to the __coveragePercent parameter of an patient object

        Parameters
        ----------
        value : string
            new percantage of the coveragePercent value.

        Returns
        -------
        self.__coveragePercent : string
            string representation of the percentage of coverage.

        """
            
        if int(value) >= 0:
            self.__coveragePercent = value
            
    
#Defining a calculateFee function to find the hospital fee that's applied coveragePercent of the object     
    def calculateFee(self):
        """
        A function that calculates the fee by using __coveragePercent and __hospitalFee 

        Returns
        -------
        self.__hospitalFee
    
            new value of the hospital fee.

        """
        if self.__isInsured:
            return self.__hospitalFee * (100-int(self.__coveragePercent)) / 100
        else:
            return self.__hospitalFee
    
#Defining a __repr__ function to return the string representation of the object     
    def __repr__(self):
        """
        Returns the representation of the class objects

        Returns
        -------
        str
            all information about the object in that class.

        """
        
        if self.__isInsured == "True" :
            a = "(yes)"
        else:
            a = "(no)"
        return "Patient Name: {}  Insurance: {}".format(self.__pName,a)