#importing datetime module to sue
import datetime
#importing Patient class to use it for inheritance
from Patient import*
#creating a Outpatient class by inheriting Patient class
class Outpatient(Patient):

#Defining an __init__ function to create a Outpatient object    
    def __init__(self, pName, isInsured,appointmentDate,appointmentTime,polyClinic,doctorName,coveragePercent=0):
        """
        

        Parameters
        ----------
        pName : str
            name of the outpatient object.
        isInsured : str
            insurance information of the outpatient object.
        appointmentDate : str
            appoitnment date information of the outpatient object.
        appointmentTime : str
            appoitnment time information of the outpatient object.
        polyClinic : str
            polyclinc information of the outpatient object.
        doctorName : str
            doctor information of the outpatient object.
        coveragePercent : str, optional
            coverage percentage information of the outpatient object. The default is 0.

        Returns
        -------
        None.

        """    
        if polyClinic == "Dentistry" or polyClinic == "Optometry":
             coveragePercent = int(coveragePercent)/2
        
        super().__init__(pName, isInsured, coveragePercent)
        self.setAppointmentDate(appointmentDate)
        self.__appointmentTime = appointmentTime
        self.__polyClinic = polyClinic
        self.__doctorName = doctorName
       
#Defining a getAppointmentDate function to get the value of date of the object   
    def getAppointmentDate(self):
        """
        Returns the apponitment date of the self object

        Returns
        -------
        self.__appointmentDate : str
            appointment date of the object.

        """
        return self.__appointmentDate
    
#Defining a getAppointmentTime function to get the value of time of the object    
    def getAppointmentTime(self):
        """
        Returns the appointment time of the self object 

        Returns
        -------
        self.appointmentTime : str
            appointment time of the object.

        """
        return self.__appointmentTime
    
#Defining a getpolyClinic function to get the clinic data of the object     
    def getpolyClinic(self):
        """
        Returns the type of polyclinic of the patient object

        Returns
        -------
        self.__polyClinic: str
            polyClinic value of the object.

        """
        return self.__polyClinic
    
#Defining a getdoctorName function to get the doctor name of the object    
    def getdoctorName(self):
        """
        Returns the doctor name of the object

        Returns
        -------
        self.__doctorName: str
            doctor name of the object.

        """
        return self.__doctorName
     
#Defining a setAppointmentDate function to set a new value of date to the object    
    def setAppointmentDate(self,appointmentDate):
       """
        Assigns a date type object to the appointmentDate variable of the object

        Parameters
        ----------
        appointmentDate : str
            straight written version of the date .

        Returns
        -------
        None.

        """
       self.__appointmentDate = datetime.datetime.strptime(appointmentDate, '%Y%m%d').date() 
    
#Defining a setAppointmentTime funciton to set a new value of time to the object 
    def setAppointmentTime(self,value):
        """
        Assigns a new value of time to the self.__appointmentTime object

        Parameters
        ----------
        value : str
            new value of time variable.

        Returns
        -------
        None

        """
        self.__appointmentTime = value
    
#Defining a setpolyClinic function to set a new value of clinic data to the object
    def setpolyClinic(self,value):
        """
        Assigns a new clinic value to the object

        Parameters
        ----------
        value : str
            new clinic data of the object.

        Returns
        -------
        None

        """
        self.__polyClinic = value
        
#Defining a setdoctorName function to set a new doctor data to the object   
    def setdoctorName(self,value):
        """
        Assigns a new doctor data to the object

        Parameters
        ----------
        value : str
            new doctor data.

        Returns
        -------
        None.
        """
        self.__doctorName = value
      
#Defining a __lt__ function to compare to different objects depending on their date and time values    
    def __lt__(self,other):
        """
        Compares to object elements and returns a True expression if self is smaller than other else False

        Parameters
        ----------
        other : a Outpatientobject that'll be compared with the "self"
            DESCRIPTION.

        Returns
        -------
        bool
            if self > other the function returns a False else True.

        """
        d = self.__appointmentDate
        do = other.__appointmentDate
        t = int(self.__appointmentTime.split(":")[0]+self.__appointmentTime.split(":")[1])
        to = int(other.__appointmentTime.split(":")[0]+other.__appointmentTime.split(":")[1])
        if d != do:
            return d < do
        else:
            return t < to  
        
#Defining a __repr__  object to get the string expression of the object 
    def __repr__(self):
        """
        Returns the string expression of the object

        Returns
        -------
        str
            string representatiion of the patient object

        """
        a = super().__repr__()
        return "\nAppointment Date: {} {} \n{} \nPoly Clinic: {} ({})\nFee: {}\n ".format(self.__appointmentDate,self.__appointmentTime,a,self.__polyClinic,self.__doctorName ,self.calculateFee())
        