from Stock import *

#Creating a function that selects objects that have more quantity than the parameter
def getByStockQuantity(stock_object1, parameter):
    b = []
    for m in stock_object1:
        if m.get_count() > parameter:
            b.append(m)
    return b

#Creating a function that selects objects that have less price than the parameter
def  getByPrice (stock_object2, parameter):
    c = []
    for t in stock_object2:
        if t.get_price() < parameter:
            c.append(t)
    return c


#Opening and getting information from the file
q = open("input.txt","r")  
list_of_stocks = []

#Adding elements of the file in Stock as objects
for i in q:
    text = i.strip().split(";")
    
    list_of_stocks.append(Stock(text[0],int(text[1]),float(text[2]),text[3]))

#Printing the objects in text file that has more quantity than 6 and less price than 5   
print("Printing Stocks whose price is less than 5 and count is over 6:")
for a in list_of_stocks:
    if a in getByStockQuantity(list_of_stocks, 6) and a in getByPrice(list_of_stocks, 5):
        print(a)
        print()