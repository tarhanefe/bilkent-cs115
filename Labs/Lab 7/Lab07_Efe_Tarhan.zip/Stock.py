#Creating a Stock class


class Stock:
    
    def __init__ (self, name, count, price, city):
        """
        Creates an object into the Stock class

        Parameters
        ----------
        name(str) : name of the object.
        count(float): quantity of the object.
        price(float): price of the object.
        city(str) : city of the object.

        Returns:
        --------    
         None.

        """
        self.__name = name
        self.__count = count
        self.__price = price
        self.__city = city
    
    
    #Creating a function to get name information of the object
    def get_name(self):
        """
        Returns the encapsulated name of an stock object
        
        Parameters:
        self (Stock): a Stock object that contains informations about itself
        -------
        Returns:
        str: Name of the object which is encapsulated (self.__name)
            

        """
        return self.__name
    
    #Creating a function to get quantity information of the object
    def get_count(self):
        
        """
        Returns the encapsulated quantity of an stock object
        
        Parameters:
        self (Stock): a Stock object that contains informations about itself
        -------
        Returns:
        str: Quantity of the object which is encapsulated (self.__count)
            

        """
        return self.__count
    
    #Creating a function to get price information of the object
    def get_price(self):
        
        """
        Returns the encapsulated price of an stock object
        
        Parameters:
        self (Stock): a Stock object that contains informations about itself
        -------
        Returns:
        str: Price of the object which is encapsulated (self.__price)
            

        """
        return self.__price
    
    #Creating a function to get city information of the object
    def get_city(self):
        
        """
        Returns the encapsulated city of an stock object
        
        Parameters:
        self (Stock): a Stock object that contains informations about itself
        -------
        Returns:
        str: City of the object which is encapsulated (self.__city)
            

        """
        
        return self.__city

    #Creating a function to set a new value of quantity information for the object
    def set_count(self,count):
        
        """
        Changes the quantity of a Stock object
        
        Parameters:
        self (Stock): a Stock object that contains informations about itself
        -------
        Returns:
        str: New quantity of the Stock object (self.__count)
            

        """
        
        self.__count = count
    
    #Creating a function to return information of the selected object 
    def __repr__(self):
        
        """
        Returns the printed version of the object
        
        Parameters:
        self (Stock): a Stock object that contains informations about itself
        -------
        Returns:
        str: representation of the object when called
        """
        
        return "Name: {} \nCount: {} \nPrice: {} \nCity: {} ".format(self.__name,self.__count, self.__price,self.__city)
    