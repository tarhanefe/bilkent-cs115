# Importing numpy and matplotlib modules to create plots
import numpy as np
import matplotlib.pyplot as plt

#Using the np.set_printoptions(suppress=True) function to show numbers with decimals
np.set_printoptions(suppress=True)

# Getting the data of countries and indicators from the text files by numpy funcitons
countries = np.loadtxt("countries.txt",dtype = str, skiprows= 1) 
indicators = np.loadtxt("indicators.txt", dtype = float, skiprows = 1)

#Getting the data of countries which has GDP lower than 1000 
indicators_under_1000 = indicators[indicators[:,-5] < 1000]

#Getting europe countries from the countries list
europe_countries = countries[countries[:,-1] == "Europe"]

#Getting europe countries datas from indicators list
europe_data = indicators[countries[:,-1] == "Europe"]

#Getting datas of employed males and females
turkey_employement_data = indicators[countries[:,0] == "Turkey"][0][7:9]

#Creating the first figure

plt.figure(1)

index = ["Europe Male", "Europe Female"]

life_expectancy = [sum(europe_data[:,3])/len(europe_countries), sum(europe_data[:,4])/len(europe_countries)]

#Creating the first graph of first figure
plt.subplot(1,2,1)

plt.bar(index[0],life_expectancy[0],width = 0.85, align= "center")
plt.bar(index[1], life_expectancy[1],width = 0.85, align= "center")
plt.title("Life Expectancy for Europe by Gender")
plt.legend(["Men","Women"],loc = 1)
plt.ylabel("Life Expectancy")
#Creating the second graph of first figure
plt.subplot(1,2,2)

plt.plot(indicators_under_1000[:,6], indicators_under_1000[:,5],"b*--")
plt.title("Infant Mortality with GDP under 1000")
plt.ylabel("Infant Morality")
plt.xlabel("GDP")

#Creating the second figure

plt.figure(2)

#Creating the first graph of the second figure
plt.subplot(2,1,1)

gender = ["Male","Female"]
plt.pie(turkey_employement_data, explode = (0,0.1), labels = gender, autopct = "%1.1f%%")
plt.title("Employement Rates by Gender in Turkey")

#Creating the second graph of the second figure
ax = plt.subplot(2,1,2)


plt.title("Frequency of Fertility Rates for All Countries (4 bins)")
data = plt.hist(indicators[:,0], 4)

ax.set_xticks(data[1].round(2))

