from doctor import*

#Defining a read_doctors() function to create class objects from a txt file
def read_doctors(file_name):
    """
    Takes a txt file and transform the lines of the txt file into class objects and returns a list

    Parameters
    ----------
    file_name : string
        name of the text file.

    Returns
    -------
    a : list
        the list that contains Doctor objects.

    """
    a = []
    doc = open(file_name, "r")
    for i in doc:
        m = i.strip().split(";")
        a.append(Doctor(m[0],m[1],m[2],m[3]))
    doc.close()
    return a 

#Defining a binary_search() function to find the wanted objects index in a list
def binary_search(list_of_doctors,wanted,s,e):
    """
    Searches and returns the index of the wanted element

    Parameters
    ----------
    list_of_doctors : list
        list that contains all elements.
    wanted : int
        wanted object.
    s : int
        start index.
    e : int
        end index.

    Returns
    -------
    int
        index of the wanted element.

    """
    if s > e:
        return -1
    else:
        mid = (s+e)//2
        if int(list_of_doctors[mid].get_doctor_id()) ==  wanted:
            return mid
        else:
            if int(list_of_doctors[mid].get_doctor_id()) >  wanted:
                return binary_search(list_of_doctors,wanted,s,mid-1)
            else:
                return binary_search(list_of_doctors,wanted,mid+1,e)

#Defining a bubble_sort() function to sort elements of a list
def bubble_sort(doct):
    """
    This function takes a list and sorts the elements inside it

    Parameters
    ----------
    doct : list
        list that will be sorted.

    Returns
    -------
    None.

    """
    state = False;
    i = 0
    while(i < len(doct)-1 and not state):
        state = True;
        for k in range(len(doct)-i-1):
                 if doct[k].get_hospital() > doct[k+1].get_hospital():
                     state = False
                     doct[k],doct[k+1] = doct[k+1],doct[k]
                 elif doct[k].get_hospital() == doct[k+1].get_hospital() and doct[k].get_specialty() > doct[k+1].get_specialty():
                     state = False
                     doct[k],doct[k+1] = doct[k+1],doct[k]
        i += 1


m = read_doctors("doctors.txt")
m.sort()

#Printing the id of the wanted doctor
doc = int(input("Enter id of doctor to search: "))
if not binary_search(m, doc, 0, len(m)-1) == -1: 
    print("Doctor with id {}".format(doc))
    print(m[binary_search(m, doc, 0, len(m)-1)])
else:
    print("No such doctor")
    
#Priniting all doctors
bubble_sort(m)
print("Doctors by Hospital and Specialty: ")    
for docs in m:
    print(docs)
    