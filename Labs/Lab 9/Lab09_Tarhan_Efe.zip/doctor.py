#Defining the doctor class
class Doctor:
    
    #Defining init function to add objects to class
    def __init__(self, dId, dName, dSpec, hosp):
        """
        This function creates doctor objects

        Parameters
        ----------
        dId : str
            doctor object's id.
        dName : str
            doctor object's name.
        dSpec : str
            doctor object's speciality.
        hosp : str
            doctor object's hospital.

        Returns
        -------
        None.

        """
        self.__doctorId = dId
        self.__doctorName = dName
        self.__specialty = dSpec
        self.__hospital = hosp
#Defining a get_doctor_id(self) function to get the value of doctor's id
    def get_doctor_id(self):
        """
        Returns the value of doctor objects id

        Returns
        -------
        str
            doctor object's id.

        """
        return self.__doctorId
    
#Defining a set_doctor_id(self, dId) to set a new is for the doctor      
    def set_doctor_id(self, dId):
        """
        Sets a new id value to doctor object

        Parameters
        ----------
        dId : str
            New value of the doctor's id.

        Returns
        -------
        None.

        """
        self.__doctorId = dId
#Defining a get_doctor_name(self) to get the value of doctor name
    def get_doctor_name(self):
        """
        Returns the value of doctor object's name'

        Returns
        -------
        str
            doctor object's name.

        """
        return self.__doctorName
#Defining a set_doctor_name(self, dName) to set a new value for doctor name
    def set_doctor_name(self, dName):
        """
        Sets a new name value to doctor object

        Parameters
        ----------
        dName : str
            new name of the object.

        Returns
        -------
        None.

        """
        self.__doctorName = dName
#Defining a get_specialty(self) to get the speciality of doctor   
    def get_specialty(self):
        """
        Returns the speciality value of the doctor object

        Returns
        -------
        str
            speciality of the doctor object.

        """
        return self.__specialty
#Defining a set_specialty(self, dSpec) to set a new speciality to doctor
    def set_specialty(self, dSpec):
        """
        Sets a new speciality value to the doctor object

        Parameters
        ----------
        dSpec : str
            new speciality of the doctor object.

        Returns
        -------
        None.

        """
        self.__specialty = dSpec
#Defining a get_hospital(self) to get the hospital of the doctor
    def get_hospital(self):
        """
        Returns the hospital value of the doctor object 

        Returns
        -------
        str
            hospital value of the doctor object.

        """
        return self.__hospital
#Defining a set_hospital(self, hosp) to set a hospital of the doctor
    def set_hospital(self, hosp):
        """
        Sets a new hospital value to the doctor object

        Parameters
        ----------
        hosp : str
            new value of the doctor object.

        Returns
        -------
        None.

        """
        self.__hospital= hosp
#Defining a __repr__(self) to return a string representation of the object
    def __repr__(self):
        """
        Creates a string representation of the class object

        Returns
        -------
        str
            str representation of the class boject.

        """
        return self.__doctorId+' '+self.__doctorName+' '+self.__specialty+' '+self.__hospital
#Defining a __lt__(self,othert) to return True if self smaller than object  
    def __lt__(self,other):
        """
        compares two class objects. If self is smaller than other returns true, else false

        Parameters
        ----------
        other : Doctor
            the other doctor that'll be compared.

        Returns
        -------
        bool
            if sel < other it returns true, else false.

        """
        return self.__doctorId < other.__doctorId
    
    
        
            