#Creating the form() function that'll rearrange the words according to numbers 
def form(q):
    """
    Gets a text file. Creates two parallel lists with the words and the numbers 
    inside the text file (words and numbers). Rearranges the words in the correct 
    order and creates a new string

    Parameters
    ----------
    q : string
        Name of the text file which'll be used

    Returns
    -------
    new_line : string
        The string that'll be made by rearranging the elements in the words 
        list according to the numbers list.

    """
    #Open the file
    inside_text = open(q, "r")
    #Create 2 empty parallel lists to append numbers and words
    words = []
    numbers = []
    m = 0
    for i in inside_text:
        x,y = i.split()
        words.append(x)
        numbers.append(y)
        m += 1
    #Reordering elements of words list according to the numbers list
    new_line = ""
    for j in range(1,m+1):
        new_line += words[numbers.index("{}".format(j))] + " "
       
    return new_line

#Printing the reordered list
print(form("words.txt"))

