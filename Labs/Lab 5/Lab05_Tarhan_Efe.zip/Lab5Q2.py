
# Defining the separate() function that'll organize the elements of a list depending to their types
def separate(m):
    """
    This function creates a dictionary that contains 4 lists of 4 different typed object as values 

    Parameters
    ----------
    m : list
        List of the elements that'll we organized depending on their types.

    Returns
    -------
    new_dict : dict
        A dictionary with keys that are object types and values that are listed objects.

    """
    new_dict = {}
    for i in m:
        if type(i) in new_dict:
            new_dict[type(i)].append(i) 
        else:
            new_dict[type(i)] = [i]
    return new_dict

m =  [2, 3.75, False, 'Today', 'CS115', 6, 1.5, 4.0, 'python', True, 25,
1.9]

#Printing the original  list
print("{} = {}".format("Original List", m))

#Getting keys and values from the dictionary and printing them
a = separate(m)
for i in a:
    print(i, " ->" ,  a[i])