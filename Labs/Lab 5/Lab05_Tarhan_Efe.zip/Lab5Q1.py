import math

#Defining the estimatE() function to create tupples
def estimatE(n):
    """
    Gets an integer value and calcualtes the following 
    serie for the number and returns a tupple holding the values 
    1, 1/1!, 1/2!, 1/3!, ...1/n!
    Parameters
    ----------
    n : integer
        n is the integer which'll be inputted the following serie
        1, 1/1!, 1/2!, 1/3!, ...1/n!
    Returns
    -------
    values : tupple
        It's the tupple that contains the serie for integer n .

    """
    values = (1,)
    
    for n1 in range(1,n+1):
        values += (1/math.factorial(n1),)
    return values


#Getting the integer from the user
a = int(input("Enter the value of n: "))

#Printing the sum of elemnts of the serie
print("E =",end=("\t"))

n3 = 0
for n4 in range(a+1):
    print(" + {}".format(estimatE(a)[n4]),end=(""))    
    n3 += estimatE(a)[n4]

print("\nEstimated Value: {}".format(n3))

#Calculating number e and error

print("Error = {}".format(math.e-n3))
