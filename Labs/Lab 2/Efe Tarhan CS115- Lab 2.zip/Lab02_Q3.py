#CREATING A FOR LOOP TO LIST ALL MULTİPLİERS OF 2
for i in range (1,11):
    print("2 to the power {} is {}".format(i, 2 ** i))

#SETTING VARIABLES TO CALCUATE THE NUMBER OF 2 THAT MULTIPLIED
raised_num = 1    

repetation = 0

while raised_num < 5000 :
    raised_num *= 2
    repetation += 1

#PUTTING A SINGLE PRINT() FUNCTION TO CREATE A BLANK LINE
print()

#PRINTING ALL VALUES TOGETHER
print("First power of 5000 < 2 is 2 to the power {} which is {}".format(repetation, raised_num ))