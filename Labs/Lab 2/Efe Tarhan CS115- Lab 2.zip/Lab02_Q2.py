#GETTING THE INCOME INPUT FROM THE USER:
income = float(input("Enter the total income(TL) : "))

#BRANCHING THE CODE FOR DIFFERENT INCOME INTERVALS:
if 10000 > income > 0 :
    net_income = income * 0.78
    print("The net income is", net_income, "TL" )

elif 100000 > income >= 10000 :
    net_income = income * 0.74
    print("The net income is ", net_income, " TL" )

elif income >= 100000 :
    net_income = income * 0.67
    print("The net income is ", net_income, " TL" )

else :
    print("Entered income value is not valid. Exiting...")