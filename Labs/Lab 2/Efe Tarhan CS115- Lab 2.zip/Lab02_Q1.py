#GETTING INTEGERS(A, B, C) FROM THE USER: 
a = int(input("Enter length of side a :"))

b = int(input("Enter length of side b :"))

c = int(input("Enter length of side c :"))

#BRANCHING THE CODE TO DETECT ERRORS ABOUT TRIANGLE EQUATION
if 0 >= a or 0 >= b or 0 >= c :
    print("Side lengths cannot be negative or zero. Exiting...")

elif a + b > c and b + c > a and a + c > b :
    print("This is a valid triangle.")

else:
    print("This is NOT a valid triangle")