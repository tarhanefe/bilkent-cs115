#GETTING A STRING INPUT FROM USER
string = str(input("Enter a string: "))

#DEFINING THE NEW STRING WITHOUT ALPHANUMERICS
new_string  = ""

#CREATING THE FOR LOOP TO ELIMINATE NON ALPHANUMERIC VALUES
for i in string:
    if i.isalnum() == False and i.isspace() == False: 
        i = ""
    new_string += i

#PRINTING THE LAST VERSION OF OUR STRING
print("New string: " + new_string)



#CREATING A WHILE LOOP TO ELIMINATE NON ALPHANUMERIC VALUES
new_string2 = ""

#DEFINING A NUMBER TO USE IN WHILE
k = 0
while k in range(len(string)):
    if string[k].isalnum() or string[k].isspace() :
        new_string2 += string[k]
    k += 1
print("New string: " + new_string2)        