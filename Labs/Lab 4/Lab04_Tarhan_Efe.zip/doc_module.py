#Defining isAllLetter() function to understand if the string contains only letters or not

def isAllLetter(str1):
    """
    The function takes a string as a parameter and returns True if the string
    is only made up of letters; otherwise, it returns False.
    Parameters:
    str1(str) : String that'll we be examined
    Returns:
    True if str1 contains only letters else False
    """
   
   
    str1 = str1.strip()
    return str1.isalpha()
   

#Defining pluralizeWord() function that plurilalizes the word that I put as input

def pluralizeWord(str2):
    
    """
    The function takes a String as a parameter and returns  
    the plural form of the noun. 
    
    Parameters:
    str2(str): Word that'll be pluralized
    
    Returns:
    str3(str) : Pluralized for of the noun
    """
   
    
    
    str2 = str2.strip()
    if str2[-1] == "y":
        str3 = str2[:-1] + "ies"
    else:
        str3 = str2 + "s"
    return str3

#Defining pluralizeAllWords() function that takes an input filename, an output filename, it reads the words in the input file pluralizes the words in the file and puts the pluralized versions of the nouns in the output file

def pluralizeAllWord(s1,s2):
    """
    The function takes an input filename, an output filename, it
    reads the words in the input file. Then it writes the plural form of the word into the
    output file. The function will find and write the percentage of the words that are
    pluralized to the end of the output file. Also prints the percantage of words that pluralized

    
    Parameters:
    
    s1(str): Name of the input file name 
    
    s2(str): Name of the output file name
    
    Returns:
    Changed version of the file
    """
    f = open(s1, "r")
    q = open(s2, "w" )
    i = 0
    j = 0
    for x in f:
        if isAllLetter(x) : 
            q.write(pluralizeWord(x) + "\n")
            j += 1
        i += 1
    q.write("{:.2f} % of the words are pluralized".format(j / i * 100))
    
    f.close()
    q.close()
        