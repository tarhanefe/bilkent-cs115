# Importing the 3 function from doc_module.py
import doc_module

# Using pluralizeAllWord() function to pluralize the words in the text
doc_module.pluralizeAllWord("wordList.txt","pluralWordList.txt")

